package com.Praktikum.Modul_5.Tugas.element;

public interface element {
  double fireDamage = 100;
  double waterDamage = 90;
  double earthDamage = 150;
  double windDamage = 80;
}
