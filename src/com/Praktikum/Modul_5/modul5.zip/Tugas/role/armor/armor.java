package com.Praktikum.Modul_5.Tugas.role.armor;

public class armor {
    public double strengthArmor=1000.0;
}
