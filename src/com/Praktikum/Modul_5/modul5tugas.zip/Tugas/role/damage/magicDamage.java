package com.Praktikum.Modul_5.Tugas.role.damage;

public interface magicDamage {
  double MAGIC_DMG_BONUS = 0.8;
}
