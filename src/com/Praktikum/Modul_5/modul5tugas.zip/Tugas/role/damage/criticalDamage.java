package com.Praktikum.Modul_5.Tugas.role.damage;

public interface criticalDamage {
 final static double  ATK_DMG_BONUS = 0.4;
}
