package com.Praktikum.Modul_5.Tugas.weapon;

public interface weaponable {
  void equipWeapon(weapon weapon);
}
