package com.Praktikum.Modul_5.Tugas.weapon;

public class gun extends weapon {

  public gun(String name, double baseDamage) {
    super(name, baseDamage);
  }
}
