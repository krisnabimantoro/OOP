package com.Praktikum.Modul_5.Tugas.weapon;

public class sword extends weapon{

    public sword(String name, double baseDamage) {
        super(name, baseDamage);
        //TODO Auto-generated constructor stub
    }
    
}
