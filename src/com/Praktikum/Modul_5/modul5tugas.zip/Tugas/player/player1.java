package com.Praktikum.Modul_5.Tugas.player;

import com.Praktikum.Modul_5.Tugas.hero;

public class player1 extends hero {
 
  
  public player1(double healthPoint, double attackDamage, double defensi, int level, boolean lifeStatus, String intro) {
    super(healthPoint, attackDamage, defensi, level, lifeStatus, intro);
    //TODO Auto-generated constructor stub
  }


  public void spawnIntro() {
    // TODO Auto-generated method stub
    throw new UnsupportedOperationException(
      "Unimplemented method 'spawnIntro'"
    );
  }


}
